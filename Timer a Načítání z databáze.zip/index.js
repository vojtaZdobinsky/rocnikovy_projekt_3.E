import "./styles.css"; //zdroj číslo 2

var mysql = require("mysql");
var volbaUzivatele;

var connection = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword",
  database: "mydb"
});

connection.connect(function (err) {
  connection.query(
    "SELECT MAX(id) AS HighestQuestionId FROM Otazky_historie",
    function (err, maxIdHistorie) {
      if (err) throw err;
      var maxHistorie = maxIdHistorie;
    }
  );
  connection.query(
    "SELECT MAX(id) AS HighestQuestionId FROM Otazky_zeměpis",
    function (err, maxIdZemepis) {
      if (err) throw err;
      var maxZemepis = maxIdZemepis;
    }
  );
  connection.query(
    "SELECT MAX(id) AS HighestQuestionId FROM Otazky_Ano/Ne",
    function (err, maxIdAN) {
      if (err) throw err;
      var maxAnoNe = maxIdAN;
    }
  );
  connection.query(
    "SELECT MAX(id) AS HighestQuestionId FROM Otazky_kultura",
    function (err, maxIdKultura) {
      if (err) throw err;
      var maxKultura = maxIdKultura;
    }
  );
  connection.query(
    "SELECT MAX(id) AS HighestQuestionId FROM Otazky_literatura",
    function (err, maxIdLiteratura) {
      if (err) throw err;
      var maxLiteratura = maxIdLiteratura;
    }
  );
  var maxH = Math.floor(Math.random * maxHistorie); //vrátí náhodné číslo od 1 do nejvyššího možného čísla v tabulce
  var maxZ = Math.floor(Math.random * maxZemepis);
  var maxAN = Math.floor(Math.random * maxAnoNe);
  var maxK = Math.floor(Math.random * maxKultura);
  var maxL = Math.floor(Math.random * maxLiteratura);
  var historie =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_historie WHERE ID = ?";
  var zeměpis =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_zeměpis WHERE ID = ?";
  var anoANe = "SELECT otazka, odpoved FROM Otazky_Ano/Ne WHERE ID = ?";
  var kultura =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_kultura WHERE ID = ?";
  var literatura =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_literatura WHERE ID = ?";
  switch (
    volbaUzivatele //na základě toho, co uživatel vybral, vybereme správný příkaz
  ) {
    case 1:
      connection.query(historie, [maxH], function (err, result) {
        //provede daný SQL příkaz na daném řádku
        if (err) throw err;
        console.log(result[0].otazka); //zde bude kód, který výsledek vypíše na front-end
        console.log(result[1].odpoved);
        console.log(result[2].obtiznost);
      });
      break;
    case 2:
      connection.query(zeměpis, [maxZ], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    case 3:
      connection.query(anoANe, [maxAN], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    case 4:
      connection.query(kultura, [maxK], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    case 5:
      connection.query(literatura, [maxL], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    default:
  }
});

const timer = () => {
  console.log("Váš čas vypršel"); //zde je určeno, co se stane, až vypřší čas
};
setTimeout(timer, 2 * 1000); //první číslo jsou milisekundy
//zdroj číslo 1
