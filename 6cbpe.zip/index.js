import "./styles.css";

var mysql = require("mysql");
var volbaUzivatele;

var connection = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword",
  database: "mydb"
});

connection.connect(function (err) {
  var adr = Math.floor(Math.random() * 100); //vrátí náhodné číslo mezi 1 a 99
  var historie =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_historie WHERE ID = ?";
  var zeměpis =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_zeměpis WHERE ID = ?";
  var anoANe = "SELECT otazka, odpoved FROM Otazky_Ano/Ne WHERE ID = ?";
  var kultura =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_kultura WHERE ID = ?";
  var literatura =
    "SELECT otazka, odpoved, obtiznost FROM Otazky_literatura WHERE ID = ?";
  switch (
    volbaUzivatele //na základě toho, co uživatel vybral, vybereme správný příkaz)
  ) {
    case 1:
      connection.query(historie, [adr], function (err, result) {
        //provede daný SQL příkaz na daném řádku
        if (err) throw err;
        console.log(result[0].otazka); //zde bude kód, který výsledek vypíše na front-end
        console.log(result[1].odpoved);
        console.log(result[2].obtiznost);
      });
      break;
    case 2:
      connection.query(zeměpis, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    case 3:
      connection.query(anoANe, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    case 4:
      connection.query(kultura, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    case 5:
      connection.query(literatura, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
      break;
    default:
  }
});
