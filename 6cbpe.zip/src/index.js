import "./styles.css";

var mysql = require("mysql");

var connection = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword",
  database: "mydb"
});

con.connect(function (err) {
  var adr = Math.floor(Math.random() * 100); //vrátí náhodné číslo mezi 1 a 99
  var historie = "SELECT otazka FROM Otazky_historie WHERE ID = ?";
  var zeměpis = "SELECT otazka FROM Otazky_zeměpis WHERE ID = ?";
  var anoANe = "SELECT otazka FROM Otazky_Ano/Ne WHERE ID = ?";
  var kultura = "SELECT otazka FROM Otazky_kultura WHERE ID = ?";
  var literatura = "SELECT otazka FROM Otazky_literatura WHERE ID = ?";
  switch (
    volbaUzivatele //na základě toho, co uživatel vybral, vybereme správný příkaz
  ) {
    case 1:
      con.query(historie, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
    case 2:
      con.query(zeměpis, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
    case 3:
      con.query(anoANe, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
    case 4:
      con.query(kultura, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
    case 5:
      con.query(literatura, [adr], function (err, result) {
        if (err) throw err;
        console.log(result); //zde bude kód, který výsledek vypíše na front-end
      });
  }
});
