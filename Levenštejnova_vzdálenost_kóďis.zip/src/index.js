let string1 = 'kotatko';
let string2 = 'kotatko';
var i = 0;
var charEqual = 0;

while(i < string1.length) {
  var n = string1.charCodeAt(i);
  var m = string2.charCodeAt(i);
  if (n == m) {
    charEqual++;
  }
  i++;
}

var vysledek = (charEqual / string1.length) * 100;
console.log("Delka 1. slova " + string1.length + "Procento: " + vysledek);
